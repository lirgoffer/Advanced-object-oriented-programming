/*Assinment 2
Autor:Lir Goffer, ID:209103274*/

#include "College.h"

using namespace std;

int main() {
    College c;
    c.menu();
    return 0;
}
