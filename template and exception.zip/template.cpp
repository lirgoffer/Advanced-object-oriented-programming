/*Assignment:4
Autor:Lir Goffer, ID:209103274*/

#include <iostream>
using namespace std;

template <typename G>
bool Symmetric(G arr[], int size) {
	int j = (size - 1);
	for (int i = 0; i < size; i++) {		
		if (arr[i] != arr[j])
			return false;
		j--;
	}
	return true;
}


template<typename G>
G* ShiftRight(G arr[], int size, int n) {
	G* temp = new G[size];
	int i = 0,j=0, num = n;
	while (num != 0) {
		temp[i] = arr[i + size - n];
		i++;
		num--;
	}
	for (i; i < size; i++) {
		temp[i] = arr[j];
		j++;
	}
	return temp;
}

void MainFunc();

int main() {

	int arr1[] = { 1,2,3,2,1 };
	char arr2[] = { 'a','b','c','d','e' };

	if (Symmetric(arr1, 5)) { //=true
		cout << "Array symmetric" << endl;
	}
	else
	cout << "Array is not symmetric" << endl;


	if (Symmetric(arr2, 5)) { //=true
		cout << "Array symmetric" << endl;
	}
	else
	cout << "Array is not symmetric" << endl;

	MainFunc(); //operate shift right

	return 0;
}

void MainFunc() {   
	char arr[] = { 'a','b','c','d','e' };
	int n = 2;
	char* shiftedArr = ShiftRight(arr, 5, n);
	cout << "new array:" << endl;
	for (int i = 0; i < 5; i++) {
		cout << shiftedArr[i];
	}
}