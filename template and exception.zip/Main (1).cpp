/*Assignment 4,
Autor: Lir Goffer, ID:209103274*/

#include"Array (1).h"
#include<iostream>
using namespace std;

int main() {
	int arr1[5] = { 2,4,5,6,7 };
	int arr2[5] = {1,2,3,4,5};
	float arr3[5] = {0.1, 4.5, 3.67, 5.9, 9};
	float arr4[5] = {9.4, 6.98, 3.0, 5.4, 3.21};
	Array<int> test(arr1, 5);
	Array<int> test2(arr2, 5);
	Array<float> test3(arr3, 5);
	Array<float> test4(arr4, 5);



	try {

		//arr1:
		int value1, value2;
		cout << "Enter value to remove:" << endl;
		cin >> value1;
		test.operator-=(value1);

		cout << "Enter value to add:" << endl;
		cin >> value2;
		test.operator+=(value2);

		test.FindIndex(5);

		if (test.IsSorted()) {
			cout << "Is sorted" << endl;
		}
		else
			cout << "Is not sorted" << endl;


		//arr2:
		cout << "Enter value to remove:" << endl;
		cin >> value1;
		test2.operator-=(value1);

		cout << "Enter value to add:" << endl;
		cin >> value2;
		test2.operator+=(value2);

		test2.FindIndex(2);

		if (test2.IsSorted()) {
			cout << "Is sorted" << endl;
		}
		else
			cout << "Is not sorted" << endl;


		//arr3:
		float val1, val2;
		cout << "Enter value to remove:" << endl;
		cin >> val1;
		test3.operator-=(val1);

		cout << "Enter value to add:" << endl;
		cin >> val2;
		test3.operator+=(val2);

		test3.FindIndex(2.4);

		if (test3.IsSorted()) {
			cout << "Is sorted" << endl;
		}
		else
			cout << "Is not sorted" << endl;


		//arr4:
		cout << "Enter value to remove:" << endl;
		cin >> val1;
		test4.operator-=(val1);

		cout << "Enter value to add:" << endl;
		cin >> val2;
		test4.operator+=(val2);

		test4.FindIndex(3.21);

		if (test4.IsSorted()) {
			cout << "Is sorted" << endl;
		}
		else
			cout << "Is not sorted" << endl;


	}
	catch (const char* msg) {
		cout << msg << endl;
	}
	try {
		cout << test[1] << endl;
	}
	catch (const char* msg) {
		cout << msg << endl;
	}

	try {
		cout << (test == test2) << endl;
	}
	catch (const char* msg) {
		cout << msg << endl;
	}
	
}