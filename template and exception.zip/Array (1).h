/*Assignment 4,
Autor: Lir Goffer, ID:209103274*/

#pragma once

#include <iostream>
#include <string>
#include <typeinfo>
using namespace std;

template<class G>
class Array {
private:
	G* arr;
	int size;

public:
	Array();
	Array(G* arr, int size);
	Array(const Array<G>& other);
	~Array();

	void PrintType() const;
	int FindIndex(G) const;
	G& operator[](int) const;
	G* FindMax() const;
	G* FindMin() const;
	Array<G>& operator+=(G);
	Array<G>& operator-=(G);
	Array<G>& operator+(Array<G>&);
	bool operator ==(Array<G>&);
	bool IsSorted()const;
	template<class G>
	friend ostream& operator<<(ostream& out,const Array<G>&);
};

template<class G>
Array<G>::Array()  //default ctor
{
	size = 0;
	arr = NULL;
}

template<class G>
Array<G>::Array(G* arr1, int size1)  //ctor
{
	this->size = size1;
	arr = new G[size];
	for (int i = 0; i < size; i++)
		arr[i] = arr1[i];
}

template<class G>
Array<G>::Array(const Array<G>& other)  //copy ctor
{
	this->size = other.size;
	/*if (this->arr != NULL) 		{ //meyutar ki obyect hadash tamid meupas
		delete[] this->arr;
	}*/

	this->arr = new G[size];//allocate memory 
	for (int i = 0; i < size; i++) 		{
		this->arr[i] = other.arr[i];
	}
}


template<class G>   //dtor
Array<G>::~Array() {
	if (arr)
	delete[] arr;
}



template<class G>
void Array<G>::PrintType() const  //print type
{
	cout << "type of array:" << typeid(*arr).name() << endl;
}



template<class G>
int Array<G>::FindIndex(G num) const   //find index
{
	int i;
	for (i = 0; i < size; i++) 	{
		if (arr[i] == num)
			return i;
	}
	throw "illegal parameter";
	return i;
}



template<class G>
G& Array<G>::operator[](int num) const  //return value
{
	if (num<0 || num>=size)
		throw "illegal index";
	return arr[num];
}



template<class G>
G* Array<G>::FindMax() const {
	if (size == 0)
		return NULL;

	G* ptr = arr;
	for (int i = 0; i < size; i++) {
		if (arr[i] > *ptr){
		ptr = &arr[i];
	   }
	}
	return ptr;
}



template<class G>
G* Array<G>::FindMin() const  //find min 
{
	if (size == 0)
		return NULL;

	G* ptr = arr;
	for (int i = 0; i < size; i++) {
		if ((arr[i]) < *ptr){
		ptr = &arr[i];
	   }
	}
	return ptr;
}

template<class G>
Array<G>& Array<G>::operator+=(G new1) {
	G* temp;
	temp = new G[size + 1];
	temp[0] = new1;
	for (int i = 1; i < size + 1; i++) {
		temp[i] = arr[i - 1];
	}
	if (arr)
		delete[] arr;
	arr = temp;
	this->size++;
	return *this;
}

template<class G>
Array<G>& Array<G>::operator-=(G value) {
	G* temp;
	int size_new = 0;

	for (int i = 0; i < size; i++) {  //count
		if (arr[i] == value)
			size_new++;
	}

	if (size_new == 0) { //if not exist
		return *this;
	}

	temp = new G[size-size_new];  //allocate memory
	int k = 0;
	for (int j = 0; j < size; j++) {
		if (arr[j] != value) {
			temp[k] = arr[j];//copy if different from value
			k++;
		}
	}
	if (arr)
		delete[] arr;
	arr = temp;
	this->size-=size_new;
	return *this;
}

template<class G>
Array<G>& Array<G>::operator+(Array<G>& add) {
	int size_new = size + add.size, j = 0;
	G* temp = new G[size_new];
	for (int i = 0; i < size_new; i++) {
		if (i < size)
			temp[i] = arr[i];
		else {
			temp[i] = add.arr[j];
			j++;
		}
	}
	if (arr)
		delete[] arr;
	arr = temp;
	size = size_new;
	return *this;
}

template<class G>
bool Array<G>::operator==(Array<G>& _check) {
	if (_check.size == 0 || size == 0)
		throw "array empty";
	if (size != _check.size)
		return false;
	for (int i = 0; i < size; i++) {
		if (arr[i] != _check.arr[i])
			return false;
	}
	return true;

}

template<class G>
bool Array<G>::IsSorted() const {
	if (size == 0 || size == 1)
		return true;

	for (int i = 0; i < size-1; i++) {
		if (arr[(i + 1)] <= arr[i])
			return false;
	}
	return true;

}

template<class G>
ostream& operator<<(ostream& out,const Array<G>& temp) {
	cout << "size is: " << temp.size << endl;
	for (int i = 0; i < temp.size; i++)
		cout << temp.arr[i] << " ";
	cout << endl;
	return out;
}